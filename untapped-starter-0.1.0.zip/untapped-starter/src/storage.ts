import type { Resource } from './types'

const STORAGE_KEY = 'untapped.resources.v1'

export const starterResources: Resource[] = [
  { id: 'sample-1', name: 'Smartphone', category: 'Technology', condition: 'Good', access: 'Owned', notes: 'Internet access and camera', createdAt: new Date().toISOString() },
  { id: 'sample-2', name: 'Basic hand tools', category: 'Tools & Equipment', condition: 'Good', access: 'Owned', notes: 'A small set for simple projects', createdAt: new Date().toISOString() },
  { id: 'sample-3', name: 'Bicycle', category: 'Transportation', condition: 'Fair', access: 'Owned', notes: 'Useful for local travel', createdAt: new Date().toISOString() },
]

export function loadResources(): Resource[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw === null) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(starterResources))
      return starterResources
    }
    const parsed: unknown = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed as Resource[] : []
  } catch {
    return []
  }
}

export function saveResources(resources: Resource[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(resources))
}
