import { useMemo, useState } from 'react'
import { Activity, ArrowUpRight, Boxes, Compass, Lightbulb, Plus, Search, Sparkles, Trash2, Wrench, X } from 'lucide-react'
import type { AccessType, Resource, ResourceCondition, ResourceCategory } from './types'
import { categories } from './types'
import { loadResources, saveResources } from './storage'

const conditions: ResourceCondition[] = ['Excellent', 'Good', 'Fair', 'Needs repair']
const accessTypes: AccessType[] = ['Owned', 'Borrowed', 'Shared', 'Available to me']

type Draft = Omit<Resource, 'id' | 'createdAt'>
const emptyDraft: Draft = { name: '', category: 'Tools & Equipment', condition: 'Good', access: 'Owned', notes: '' }

function App() {
  const [resources, setResources] = useState<Resource[]>(loadResources)
  const [query, setQuery] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [draft, setDraft] = useState<Draft>(emptyDraft)
  const [activeTab, setActiveTab] = useState('Resources')
  const [notice, setNotice] = useState('')

  const filtered = useMemo(() => resources.filter(item =>
    `${item.name} ${item.category} ${item.notes}`.toLowerCase().includes(query.toLowerCase())
  ), [resources, query])

  function update(next: Resource[]) {
    setResources(next)
    saveResources(next)
  }

  function openNew() {
    setEditingId(null)
    setDraft(emptyDraft)
    setShowForm(true)
  }

  function openEdit(item: Resource) {
    setEditingId(item.id)
    setDraft({ name: item.name, category: item.category, condition: item.condition, access: item.access, notes: item.notes })
    setShowForm(true)
  }

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const name = draft.name.trim()
    if (!name) return
    if (editingId) {
      update(resources.map(item => item.id === editingId ? { ...item, ...draft, name } : item))
      setNotice('Resource updated')
    } else {
      const item: Resource = { ...draft, name, id: crypto.randomUUID(), createdAt: new Date().toISOString() }
      update([item, ...resources])
      setNotice('Resource added')
    }
    setShowForm(false)
    setEditingId(null)
    setDraft(emptyDraft)
    window.setTimeout(() => setNotice(''), 2400)
  }

  function remove(id: string) {
    if (!window.confirm('Delete this resource?')) return
    update(resources.filter(item => item.id !== id))
    setNotice('Resource deleted')
    window.setTimeout(() => setNotice(''), 2400)
  }

  const ownedCount = resources.filter(item => item.access === 'Owned').length

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#" aria-label="UNTAPPED home"><span className="brand-mark"><Sparkles size={21} /></span><span>UN<span>TAPPED</span><small>DISCOVER WHAT'S POSSIBLE</small></span></a>
        <div className="side-label">WORKSPACE</div>
        {[
          { name: 'Overview', icon: Activity },
          { name: 'Resources', icon: Boxes },
          { name: 'Abilities', icon: Lightbulb },
          { name: 'Discover', icon: Compass },
        ].map(({ name, icon: Icon }) => (
          <button key={name} className={`nav-item ${activeTab === name ? 'active' : ''}`} onClick={() => setActiveTab(name)}>
            <Icon size={18} /><span>{name}</span>{name === 'Discover' && <span className="soon">SOON</span>}
          </button>
        ))}
        <div className="sidebar-bottom"><div className="status-dot" /> CORE PROTOTYPE <span>0.1</span></div>
      </aside>

      <section className="main-area">
        <header className="topbar"><div className="breadcrumb">Workspace <span>/</span> <b>{activeTab}</b></div><div className="profile-chip"><span className="avatar">U</span><span>My space</span></div></header>
        <div className="content">
          <section className="hero">
            <div className="hero-glow" />
            <div className="eyebrow"><span className="pulse" /> YOUR POTENTIAL, IN MOTION</div>
            <h1>What you have<br /><em>is a starting point.</em></h1>
            <p>Every resource holds a possibility. Let's find yours.</p>
            <button className="hero-button" onClick={openNew}><Plus size={17} /> Add a resource <ArrowUpRight size={16} /></button>
            <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><div className="hero-core"><Sparkles size={27} /></div>
          </section>

          {activeTab !== 'Resources' && activeTab !== 'Overview' && (
            <div className="future-note"><Sparkles size={18} /><div><b>{activeTab} is on the roadmap.</b><span>We're building the foundation first. Resource management is the first working module.</span></div></div>
          )}

          <section className="stats-grid">
            <article className="stat-card"><div className="stat-icon cyan"><Boxes size={18} /></div><span className="stat-label">TOTAL RESOURCES</span><strong>{resources.length.toString().padStart(2, '0')}</strong><small>Items in your inventory</small></article>
            <article className="stat-card"><div className="stat-icon violet"><Wrench size={18} /></div><span className="stat-label">OWNED BY YOU</span><strong>{ownedCount.toString().padStart(2, '0')}</strong><small>Available resources</small></article>
            <article className="stat-card"><div className="stat-icon green"><Lightbulb size={18} /></div><span className="stat-label">POSSIBILITIES</span><strong>—</strong><small>Discovery engine coming next</small></article>
          </section>

          <section className="section-heading"><div><div className="eyebrow">YOUR INVENTORY</div><h2>My resources <span>{resources.length}</span></h2><p>Start with what you already have access to.</p></div><button className="primary-button" onClick={openNew}><Plus size={17} /> Add resource</button></section>

          <div className="toolbar"><div className="search-box"><Search size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search your resources..." /></div><span className="private-label"><span /> Stored on this device</span></div>

          {filtered.length === 0 ? <div className="empty-state"><Boxes size={30} /><b>{resources.length ? 'No matching resources' : 'Your next idea starts here.'}</b><p>{resources.length ? 'Try another search.' : 'Add something you own, can borrow, or have access to.'}</p><button className="primary-button" onClick={openNew}><Plus size={17} /> Add your first resource</button></div> :
            <div className="resource-grid">{filtered.map(item => <article className="resource-card" key={item.id}><div className="resource-card-top"><div className="resource-symbol"><Boxes size={19} /></div><span className="resource-category">{item.category}</span><button className="icon-button" onClick={() => remove(item.id)} aria-label={`Delete ${item.name}`}><Trash2 size={16} /></button></div><h3>{item.name}</h3><p>{item.notes || 'No notes added yet.'}</p><div className="resource-meta"><span>{item.condition}</span><span>{item.access}</span></div><button className="edit-link" onClick={() => openEdit(item)}>Edit resource <ArrowUpRight size={14} /></button></article>)}</div>
          }
          <footer>UNTAPPED <span>·</span> FIND VALUE IN WHAT YOU ALREADY HAVE.</footer>
        </div>
      </section>

      {notice && <div className="toast">{notice}</div>}
      {showForm && <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) setShowForm(false) }}><section className="resource-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-heading"><div><div className="eyebrow">{editingId ? 'REFINE YOUR INVENTORY' : 'EXPAND YOUR POSSIBILITIES'}</div><h2 id="modal-title">{editingId ? 'Edit resource' : 'Add a resource'}</h2></div><button className="icon-button" onClick={() => setShowForm(false)} aria-label="Close"><X size={19} /></button></div><form onSubmit={submit}><label>RESOURCE NAME<input autoFocus required maxLength={70} value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} placeholder="e.g. Cordless drill" /></label><label>CATEGORY<select value={draft.category} onChange={event => setDraft({ ...draft, category: event.target.value as ResourceCategory })}>{categories.map(value => <option key={value}>{value}</option>)}</select></label><div className="form-row"><label>CONDITION<select value={draft.condition} onChange={event => setDraft({ ...draft, condition: event.target.value as ResourceCondition })}>{conditions.map(value => <option key={value}>{value}</option>)}</select></label><label>ACCESS TYPE<select value={draft.access} onChange={event => setDraft({ ...draft, access: event.target.value as AccessType })}>{accessTypes.map(value => <option key={value}>{value}</option>)}</select></label></div><label>NOTES <span className="optional">OPTIONAL</span><textarea rows={3} maxLength={300} value={draft.notes} onChange={event => setDraft({ ...draft, notes: event.target.value })} placeholder="Anything useful to know about this resource..." /></label><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setShowForm(false)}>Cancel</button><button type="submit" className="primary-button">{editingId ? 'Save changes' : 'Save resource'} <ArrowUpRight size={16} /></button></div></form></section></div>}
    </main>
  )
}

export default App
