export type ResourceCategory =
  | 'Tools & Equipment'
  | 'Technology'
  | 'Materials'
  | 'Transportation'
  | 'Space'
  | 'Household'
  | 'Other'

export type ResourceCondition = 'Excellent' | 'Good' | 'Fair' | 'Needs repair'
export type AccessType = 'Owned' | 'Borrowed' | 'Shared' | 'Available to me'

export interface Resource {
  id: string
  name: string
  category: ResourceCategory
  condition: ResourceCondition
  access: AccessType
  notes: string
  createdAt: string
}

export const categories: ResourceCategory[] = [
  'Tools & Equipment', 'Technology', 'Materials', 'Transportation', 'Space', 'Household', 'Other',
]
