# UNTAPPED — Starter 0.1.0

A mobile-first React + TypeScript + Vite starter for UNTAPPED.

## Current implementation

- Responsive futuristic dashboard.
- Resource create, edit, and delete.
- Resource category, condition, and access type.
- Browser-local persistence using `localStorage`.
- Sample resources for first launch.

## Important limitations

This is a frontend prototype. Data is stored only in the current browser on the current device. It is **not** synced, backed up, authenticated, or private from someone who can access the same browser profile. Do not enter sensitive information. Supabase authentication and database persistence are planned, not implemented.

## Run

```bash
npm install
npm run dev
```

Open the forwarded port 5173 in the Codespaces Ports panel.

## Verify production build

```bash
npm run build
```
